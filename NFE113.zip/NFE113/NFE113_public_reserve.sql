INSERT INTO public.reserve (id, salleid, duree, datedebut, datefin, code, status)
VALUES (16, 2, 1, '2018-06-27 08:00:00.000000', '2018-06-27 09:00:00.000000', 'PNzdIwws', 1);