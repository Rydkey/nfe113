INSERT INTO public.typesalle (id, nom) VALUES (2, 'Classique');
INSERT INTO public.typesalle (id, nom) VALUES (3, 'Audition et web conférence');
INSERT INTO public.typesalle (id, nom) VALUES (4, 'Classique audition');
INSERT INTO public.typesalle (id, nom) VALUES (5, 'Salle spécifique aux handicaps visuels');
INSERT INTO public.typesalle (id, nom) VALUES (6, 'Salle spécifique avec logiciels spécifiques');
INSERT INTO public.typesalle (id, nom) VALUES (1, 'Simple');