<?php
//use landingBundle\Form\Type\adminType;
//use landingBundle\Form\Type\landingType;

require_once __DIR__ . '/Controller/IndexController.php';
require_once __DIR__ . '/Controller/ConnectionController.php';
require_once __DIR__ . '/Controller/ReservationController.php';
require_once __DIR__ . '/Controller/SalleController.php';
require_once __DIR__ . '/Controller/TypeSalleController.php';
